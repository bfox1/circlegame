package io.github.bfox1.BallroomGame.utility;

/**
 * Created by bfox1 on 9/1/2017.
 */
public class BallRoomUtilities
{

    public static int randomInt(int min, int max)
    {
        int rand = (int) (Math.random() * max ) + 1;


        int total = rand + min;

        if(total > max) total -= total-max;
        if(total < min) total += min-total;

        return total;
    }
}
