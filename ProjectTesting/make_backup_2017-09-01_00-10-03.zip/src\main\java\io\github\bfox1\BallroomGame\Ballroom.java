package io.github.bfox1.BallroomGame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created by bfox1 on 8/28/2017.
 * This game is poorly written. Was normally a testing project which turned into a mess of testing
 * and experimenting
 * I will document as much as possible
 */
public class Ballroom extends JFrame
{
    /*
    Initializing static variables
     */
    public static final int WIDTH = 500;

    public static final int HEIGHT = 500;


    public static Ballroom ballroom;
    /*
    End of static variables.
     */

    private PaintSurface canvas;
    private JLabel label;
    private Button restartButton;

    private final CountDownTimer timer = new CountDownTimer();
    private ScheduledThreadPoolExecutor executor;

    private int points = 0;

    private int misses = 0;

    public static void main(String[] args)
    {
        ballroom = new Ballroom();
        ballroom.init();
    }

    /**
     * Initializes the Game and the BallRoomGame JFrame.
     * Also executes thread.
     */
    public void init()
    {
        this.setSize(WIDTH, HEIGHT);


        //Creating Components//

        canvas = new PaintSurface();
        label = new JLabel();
        this.restartButton = new Button();

        //Adding information to components//
        this.restartButton.setLabel("Restart Game");
        label.setText("Hits: " + points + " Misses: " + misses);
        //Setting ActionListener for Restart Button//
        this.restartButton.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                restartGame();
            }
        });


        //Adding Components to Frame//
        this.add(label, BorderLayout.NORTH);
        this.add(canvas, BorderLayout.CENTER);
        this.add(restartButton, BorderLayout.SOUTH);

        //Additional information being set here//
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);

        //Executing Thread//
        executor = new ScheduledThreadPoolExecutor(3);
        executor.scheduleAtFixedRate(new AnimationThread(this),0L, 20L, TimeUnit.MILLISECONDS);

    }

    /**
     * Invokes Restart. Will determine if game can do a Soft reset or a Hard Reset.
     */
    private void restartGame()
    {
        if(timer.getInterval() == 0)
        {
            restartGameI();
        }
        else
        {
            points = 0;
            misses = 0;
            timer.restart();
        }
    }

    /**
     * Invokes Restart. This method should only be used to invoke a Hard Reset
     */
    private static void restartGameI()
    {

        ballroom.setVisible(false);
        ballroom.executor.shutdown();
        ballroom = null;
        ballroom = new Ballroom();
        ballroom.init();
    }

    /**
     * This is the Animation Thread.
     * Constantly gets executed by Thread and controls Painting.
     */
    class AnimationThread implements Runnable
    {

        JFrame c;

        public AnimationThread(JFrame c)
        {
            this.c = c;

            timer.timer();
        }
        public void run()
        {
            label.setText("Hits: " + points + " Misses: " + misses + " TimeLeft: " + timer.getInterval());
            if(timer.getInterval() != 0)
            {
                c.repaint();
            }
            else
            {

                c.remove(canvas);
                label.setText("You hit a total of " + points + " Circles and Missed " + misses+" Lasting a total of " + timer.getTotalTime() + "!");
                c.repaint();

            }

        }
    }

    /**
     * This is the Canvas that gets painted. Main screen with the Circles.
     */
    class PaintSurface extends JComponent
    {

        public ArrayList<Ball> balls = new ArrayList<Ball>();

        Rectangle2D r = new Rectangle2D.Float(0,0, 0, 0);

        public PaintSurface()
        {
            //Creating the Balls//
            for(int i = 0; i < 10; i++)
            {
                balls.add(new Ball(30, balls));
            }

            //Adding our Listener for mouse Clicks
            this.addMouseListener(new MouseListener()
            {
                //UNUSED//
                public void mouseClicked(MouseEvent e) {}

                public void mousePressed(MouseEvent e)
                {
                    int clickedX = e.getX();
                    int clickedY = e.getY();
                    Rectangle2D rectangle2D = new Rectangle2D.Float(clickedX, clickedY, 5, 5);
                    r = rectangle2D;
                }
                //UNUSED//
                public void mouseReleased(MouseEvent e) {}
                //UNUSED//
                public void mouseEntered(MouseEvent e) {}
                //UNUSED//
                public void mouseExited(MouseEvent e) {}
            });
        }


        /**
         * This method gets Invoked everytime JFrame.repaint() gets invoked.
         * This handles all final calculations of the balls and determines if they should get destroyed and moved.
         * @param g
         */
        public void paint(Graphics g)
        {

            Graphics2D g2 = (Graphics2D) g;


            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(Color.RED);

            g2.draw(r);

            int i = 0;
            boolean flag = false;
            for(Ball ball : balls)
            {
                //Checking if ball intersects Players click.
                if(ball.intersects(r))
                {
                    if(ball.isBlue)
                    {
                        timer.addInterval(10);
                    }
                    if(ball.isGreen)
                    {
                        ball.d = ball.d * 4;
                    }
                    flag = true;
                    r = new Rectangle2D.Float(0,0,0,0);
                    continue;
                }
                if(!flag)
                {
                    i++;
                }
                if(ball.blue())
                {
                    g2.setColor(Color.BLUE);
                    ball.move();
                    g2.fill(ball);
                    g2.setColor(Color.RED);
                }
                else if(ball.isGreen)
                {
                    g2.setColor(Color.GREEN);
                    ball.move();
                    g2.fill(ball);
                    g2.setColor(Color.RED);
                }
                else
                {
                    ball.move();

                    g2.fill(ball);
                }
            }

            //If ball intersects player, will get removed, and a new one spawns.
            if(flag)
            {
                balls.remove(i);
                balls.add(new Ball(new MathHelper().randomInt(20, 50), balls));
                points++;
            }
            else if(r.getX() != 0 && r.getY() != 0)
            {

                misses++;
            }
            r = new Rectangle2D.Float(0,0,0,0);
        }
    }




}
