package io.github.bfox1.BallroomGame.circles;

import io.github.bfox1.BallroomGame.Ballroom;
import io.github.bfox1.BallroomGame.utility.BallRoomUtilities;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

/**
 * Created by bfox1 on 9/1/2017.
 */
public class Circle extends Ellipse2D.Float
{
    private int xSpeed, ySpeed;

    private int d;

    private int width = Ballroom.WIDTH;
    private int height = Ballroom.HEIGHT;

    private boolean isBlue = false;

    private boolean isGreen = false;

    private ArrayList<Circle> balls;

    /**
     * Constructor determines what type of ball its going to be. It has a chance to be either Blue, Red and Green.
     * @param d
     * @param balls
     */
    public Circle(int d, ArrayList balls)
    {
        super((int)(Math.random() * (Ballroom.WIDTH - d) +1), (int)(Math.random() *(Ballroom.HEIGHT - d) + 1), d, d);
        this.balls = balls;
        this.d = d;

        this.xSpeed = (int)(Math.random() * 5 +1);
        this.ySpeed = (int)(Math.random() * 5 + 1);

        int b = BallRoomUtilities.randomInt(5, 10);

        int g = BallRoomUtilities.randomInt(5, 50);
        if(b == 7)
        {
            this.isBlue = true;
        }
        if(g == 29)
        {
            this.isGreen = true;
        }
        this.xSpeed += 2;
        this.ySpeed += 2;

    }

    public boolean blue()
    {
        return isBlue;
    }

    /**
     * Actual movements take place here.
     */
    public void move()
    {

        //Detect collision with other balls
        Rectangle2D r = new Rectangle2D.Float(super.x, super.y, d, d);
        ArrayList ballCols = new ArrayList<Integer>();
        int i = 0;
        for(Circle b : balls)
        {
            if(b != this && b.intersects(r))
            {
                if(this.isGreen && d > 30)
                {
                    ballCols.add(i);
                }
                else
                {
                    int tempX = xSpeed;
                    int tempY = ySpeed;
                    xSpeed = b.xSpeed;
                    ySpeed = b.ySpeed;
                    b.xSpeed = tempX;
                    b.ySpeed = tempY;


                    break;
                }
            }
        }
        if(this.isGreen && d > 30)
        {
            for (int z = 0; z < ballCols.size(); z++) {
                int f = (Integer) ballCols.get(z);
                balls.remove(f);

            }
        }
        else {
            if (super.x < 0) {
                super.x = 0;
                xSpeed = Math.abs(xSpeed);
            } else if (super.x > width - d - 12) {
                super.x = width - d - 12;
                xSpeed = -Math.abs(xSpeed);
            }
            if (super.y < 0) {
                super.y = 0;
                ySpeed = Math.abs(ySpeed);
            } else if (super.y > height - d - 75) {
                super.y = height - d - 75;
                ySpeed = -Math.abs(ySpeed);
            }
            super.x += xSpeed;
            super.y += ySpeed;
        }
    }
}
